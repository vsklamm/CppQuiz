package com.vsklamm.cppquiz.utils;

public enum FlipperChild {

    MAIN_CONTENT,

    LOADING_VIEW,

    NO_INTERNET_VIEW,

    NO_QUESTIONS_VIEW,

    QUIZ_FINISHED

}
